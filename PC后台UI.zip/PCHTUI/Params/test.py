import random
from selenium import webdriver
import os,time
from selenium.webdriver.common.by import By
project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
de = webdriver.Chrome(r"E:\guge\chromedriver.exe")
de.maximize_window()
de.get(r"http://admin.bsapo.com/")
def imp(a):
    a = de.implicitly_wait(a)
    return a
s = imp(5)
de.find_element_by_xpath('//*[@id="app"]/div/div/div[2]/div[3]/div[1]/input').send_keys('17611540838')
s
de.find_element_by_xpath('//*[@id="app"]/div/div/div[2]/div[3]/div[2]/input').send_keys('a123456')
s
de.find_element_by_xpath('//*[@id="app"]/div/div/div[2]/div[3]/button').click()
s
de.find_element_by_xpath('//*[@id="app"]/div/div[1]/div/ul/li[1]/div').click()
s
de.find_element_by_xpath('//*[@id="app"]/div/div[1]/div/ul/li[1]/ul/li[1]').click()
for i in range(2,20):
    try:
        de.find_element_by_xpath("//*[@id='app']/div/div[2]/div[2]/div/table/tr["+str(i)+"]/td[11]/a[1]")
        s
        de.find_element_by_xpath("//*[@id='app']/div/div[2]/div[2]/div/table/tr["+str(i)+"]/td[11]/a[1]").click()
        s
        # de.find_element_by_xpath('/html/body/div[7]/div[2]/div/div/div[2]/div/div/textarea')
        s
        try:
            de.find_elements_by_xpath("/html/body/div[7]/div[2]/div/div/div[2]/div/div/textarea")
            time.sleep(3)
            de.find_element_by_xpath("/html/body/div[7]/div[2]/div/div/div[2]/div/div/textarea").send_keys('阿萨德')
            time.sleep(3)
            de.find_element_by_xpath('/html/body/div[7]/div[2]/div/div/div[3]/div/span[2]').click()
            time.sleep(2)
        except:
            de.find_element_by_xpath('/html/body/div[8]/div[2]/div/div/div[3]/div/span[2]').click()
            time.sleep(2)
    except:
        print('循环结束')
        break