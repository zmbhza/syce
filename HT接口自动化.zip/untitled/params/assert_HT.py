###断言
def assert_1(s):
        assert s == '操作成功.'

def assert_2(c):
        assert c == '删除成a功'
