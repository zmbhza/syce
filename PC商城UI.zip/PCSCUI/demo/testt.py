
import MySQLdb,time
import pymysql
from demo import index
# 1、连接MySQL数据库
def sql(bb):
    s = pymysql.connect(
        host="47.111.103.72",  # 数据库地址
        port=26535,  # 端口号
        db='qs_3.0_product',  # 数据库名
        user="root",  # 用户名
        passwd="WYmjdijDldsiqnporelease",  # 密码
        charset="utf8",  # 指定字符编码
    )
    c = s.cursor()
    sq = "SELECT name FROM tb_product_cash_sale WHERE NAME like %s  LIMIT 1"    # 2、读user表的数据
    c.execute(sq,'%'+'123')   # 执行sql语句
    try:
        ((row,),) = c.fetchall()    # 全部读出来
        print(row)
        if bb in row:
            print('查询到新增数据')
        else:
            print('未查询到对应的数据') #删除库中信息后可报此错误
    except:
        print('未查询到')
    c.close()

sql('123')
